"""BookExpert Document Q&A (RAG) Streamlit UI.

Run everything from one command:

    streamlit run app.py

Upload or ingest documents, build the index, and ask grounded questions with
citations, all from this page.
"""
import os

import streamlit as st

from src import config
from src import ingest as ingest_module
from src import query as query_module
from src.embeddings import using_gemini

st.set_page_config(page_title="BookExpert Document Q&A", layout="wide")

# ---------------------------------------------------------------- sidebar ----
with st.sidebar:
    st.header("Configuration")

    if using_gemini():
        st.success("Gemini mode: real semantic search is active.")
    else:
        st.warning(
            "Offline mode: no GEMINI_API_KEY set. Retrieval uses a local hash "
            "fallback and answers are not generated. Add a key to .env for real RAG."
        )

    data_dir = st.text_input("Data directory", value=config.DATA_DIR)
    db_path = st.text_input("Index (DB) path", value=config.CHROMA_DB_PATH)

    st.caption(f"Embedding model: {config.EMBEDDING_MODEL}")
    st.caption(f"Generation model: {config.GENERATION_MODEL}")

    st.divider()
    st.subheader("Build the index")

    uploaded = st.file_uploader(
        "Add files (saved to the data directory)",
        type=["pdf", "docx", "txt", "md"],
        accept_multiple_files=True,
    )
    if uploaded:
        os.makedirs(data_dir, exist_ok=True)
        for f in uploaded:
            with open(os.path.join(data_dir, f.name), "wb") as out:
                out.write(f.getbuffer())
        st.success(f"Saved {len(uploaded)} file(s) to {data_dir}")

    col_a, col_b = st.columns(2)
    with col_a:
        if st.button("Ingest", use_container_width=True, type="primary"):
            with st.spinner("Extracting, chunking and embedding..."):
                try:
                    n = ingest_module.ingest(data_dir=data_dir, db_path=db_path)
                    if n:
                        st.success(f"Indexed {n} chunks.")
                    else:
                        st.info("No supported documents found to ingest.")
                except Exception as e:
                    st.error(f"Ingestion failed: {e}")
    with col_b:
        if st.button("Reset index", use_container_width=True):
            ingest_module.reset_index(db_path=db_path)
            st.success("Index cleared.")

    status = ingest_module.index_status(db_path=db_path)
    if status["exists"] and status["count"]:
        st.metric("Indexed chunks", status["count"])
    else:
        st.caption("No index yet. Add documents and click Ingest.")

# ------------------------------------------------------------------- main ----
st.title("BookExpert Document Q&A")
st.write(
    "Ask questions about your documents. Answers are grounded strictly in the "
    "indexed sources and include inline citations."
)

ready = ingest_module.index_status(db_path=db_path)["count"] > 0
if not ready:
    st.info(
        "Build an index from the sidebar first: upload files or use the data "
        "folder, then click Ingest."
    )

with st.form("ask"):
    q = st.text_input(
        "Your question",
        placeholder="e.g. What is the formula for the mean of grouped data?",
    )
    k = st.slider("Chunks to retrieve (top-k)", min_value=1, max_value=10, value=3)
    submitted = st.form_submit_button("Ask", type="primary", disabled=not ready)

if submitted:
    if not q.strip():
        st.warning("Enter a question first.")
    else:
        with st.spinner("Retrieving context and generating answer..."):
            try:
                out = query_module.query_rag_pipeline(q, k=int(k), db_path=db_path)

                st.subheader("Answer")
                st.markdown(out.get("answer", ""))

                citations = out.get("citations", [])
                raw_context = out.get("raw_context", [])

                left, right = st.columns(2)
                with left:
                    st.subheader("Citations")
                    if citations:
                        for c in citations:
                            st.markdown(f"- {c}")
                    else:
                        st.caption("No citations returned.")
                with right:
                    st.subheader("Retrieved chunks")
                    st.caption(f"{len(raw_context)} chunk(s) used as context.")

                with st.expander("Show raw retrieved context"):
                    for cite, doc in zip(citations, raw_context):
                        st.markdown(f"**[{cite}]**")
                        st.write(doc)
                        st.divider()
            except Exception as e:
                st.error(f"Query failed: {e}")

st.divider()
st.caption("Built with ChromaDB and Google Gemini. Run with: streamlit run app.py")
