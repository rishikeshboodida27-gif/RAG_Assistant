# BookExpert — Document Q&A with RAG

A Retrieval-Augmented Generation (RAG) pipeline that answers questions about your
own documents (PDF / DOCX / TXT / MD) using a local **ChromaDB** vector store and
**Google Gemini** for embeddings and answer generation. Answers are strictly
grounded in the source documents and include inline citations (filename + page).

## Architecture

```
Documents (data/) ──> extract pages ──> recursive chunking (overlap)
        └──> Gemini embeddings ──> persistent ChromaDB (db/)
User question ──> embed (same model) ──> top-k similarity search
        └──> grounded prompt ──> Gemini ──> answer + citations
```

The same embedding function is used for ingestion and querying — this is required
for retrieval to work.

## Quickstart

1. Create and activate a virtualenv (Python 3.11+):

   ```bash
   python -m venv venv
   # Windows:  venv\Scripts\activate
   # macOS/Linux:  source venv/bin/activate
   pip install -r requirements.txt
   ```

2. Add your Gemini API key. Copy `.env.example` to `.env` and set:

   ```
   GEMINI_API_KEY=your_api_key_here
   ```

   Get a key at https://aistudio.google.com/apikey. **Never commit `.env`.**

3. Place source documents in the `data/` folder.

4. Ingest documents into the local ChromaDB:

   ```bash
   python -m src.main ingest
   ```

5. Query the knowledge base:

   ```bash
   python -m src.main query --q "What is the formula for the mean of grouped data?"
   ```

## Streamlit demo

```bash
streamlit run app.py
```

The sidebar lets you ingest documents from `data/` and run queries interactively.

## Project layout

- `src/config.py` — configuration (keys, model names, paths, chunk sizes) from env.
- `src/utils.py` — PDF/DOCX/text extraction and recursive overlapping chunking.
- `src/embeddings.py` — selects the Gemini embedding function (or an offline
  deterministic fallback when no key is set), shared by ingest and query.
- `src/ingest.py` — extraction → chunking → persistent ChromaDB collection.
- `src/query.py` — retrieval + strictly-grounded Gemini generation with citations.
- `src/main.py` — CLI entry point (`ingest` / `query`).
- `app.py` — Streamlit UI.
- `tests/` — pytest unit tests for extraction and chunking.

## Models

- Embeddings: `models/gemini-embedding-001` (override with `EMBEDDING_MODEL`).
- Generation: `gemini-2.5-flash` (override with `GENERATION_MODEL`).

## Offline / no-key mode

If `GEMINI_API_KEY` is not set, the pipeline falls back to a local deterministic
hash embedding and returns the top retrieved passage instead of a generated
answer. This keeps the app and tests runnable without a key, but retrieval
quality is poor — set a key for real semantic search.

## Notes on grounding

The system prompt instructs the model to use only the provided context, cite
sources inline as `(filename, Page X)`, and decline when the answer is not
present in the documents.
