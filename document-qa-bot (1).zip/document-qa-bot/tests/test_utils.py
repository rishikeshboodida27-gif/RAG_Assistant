from src import utils


def test_chunking_small_text():
    pages = [{"text": "This is a small document. It has two sentences.", "metadata": {"source": "test.txt", "page": 1}}]
    chunks = utils.chunk_extracted_pages(pages, chunk_size=50, chunk_overlap=10)
    assert len(chunks) >= 1
    assert all('text' in c and 'metadata' in c for c in chunks)


def test_text_file_extraction(tmp_path):
    p = tmp_path / "sample.txt"
    p.write_text("Hello world\n\nSecond paragraph.")
    res = utils.extract_text_file(str(p))
    assert isinstance(res, list)
    assert res and res[0]['metadata']['source'] == 'sample.txt'
