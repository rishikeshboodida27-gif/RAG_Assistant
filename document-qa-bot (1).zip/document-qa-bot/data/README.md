Place your source documents in this folder. Example filenames from the spec:

- annual_report.pdf
- policy_doc.pdf
- factsheet.docx

Do not commit large binary files to the repository; keep them locally or in external storage.
