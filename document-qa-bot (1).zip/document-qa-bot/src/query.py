"""Query pipeline.

Loads the persisted ChromaDB collection, retrieves the top-k chunks most
relevant to the user's question (embedding the query with the SAME function
used at ingestion), builds a strictly-grounded prompt, and asks Gemini to
answer with inline citations.
"""
import chromadb

try:
    import google.generativeai as genai
except Exception:
    genai = None

from . import config
from .embeddings import get_embedding_function, using_gemini

SYSTEM_PROMPT = (
    "You are a precise document Q&A assistant. Use ONLY the provided context to "
    "answer the user's question. Cite sources inline next to each fact using the "
    "format (filename, Page X). If the answer cannot be found in the context, "
    "respond exactly: 'I am sorry, but the provided documents do not contain the "
    "answer to your question.' Do not use outside knowledge and do not hallucinate."
)


def query_rag_pipeline(
    user_query: str, k: int = 3, collection_name: str = None, db_path: str = None
) -> dict:
    collection_name = collection_name or config.CHROMA_COLLECTION
    db_path = db_path or config.CHROMA_DB_PATH

    client = chromadb.PersistentClient(path=db_path)
    collection = client.get_collection(
        name=collection_name, embedding_function=get_embedding_function()
    )

    results = collection.query(query_texts=[user_query], n_results=k)
    docs = results.get("documents", [[]])[0]
    metadatas = results.get("metadatas", [[]])[0]

    context_blocks = []
    citations = []
    for doc, meta in zip(docs, metadatas):
        citation = f"{meta.get('source', 'unknown')}, Page: {meta.get('page', '?')}"
        context_blocks.append(f"[Source: {citation}]\n{doc}")
        citations.append(citation)

    context_payload = "\n\n---\n\n".join(context_blocks)
    prompt = (
        f"{SYSTEM_PROMPT}\n\n"
        f"CONTEXT INFORMATION:\n{context_payload}\n\n"
        f"USER QUESTION: {user_query}\n\n"
        f"GROUNDED ANSWER:"
    )

    answer = _generate_answer(prompt, docs, citations)
    return {"answer": answer, "citations": citations, "raw_context": docs}


def _generate_answer(prompt: str, docs, citations) -> str:
    """Generate with Gemini; degrade gracefully if no key/SDK is available."""
    if using_gemini() and genai is not None:
        genai.configure(api_key=config.GEMINI_API_KEY)
        model = genai.GenerativeModel(config.GENERATION_MODEL)
        response = model.generate_content(prompt)
        return response.text

    # No generation backend available — return the top retrieved chunk so the
    # retrieval half of the pipeline is still demonstrable offline.
    if docs:
        cite = citations[0] if citations else "unknown"
        return (
            "[No Gemini API key configured — showing the top retrieved passage "
            f"instead of a generated answer.]\n\nMost relevant context ({cite}):\n{docs[0]}"
        )
    return "No Gemini API key configured and no documents were retrieved."


def query(q: str, k: int = 3):
    return query_rag_pipeline(q, k=k)


if __name__ == "__main__":
    import argparse

    p = argparse.ArgumentParser()
    p.add_argument("--q", required=True)
    p.add_argument("--k", type=int, default=3)
    args = p.parse_args()
    out = query_rag_pipeline(args.q, k=args.k)
    print(out["answer"])
