import argparse
from . import ingest, query

def main():
    parser = argparse.ArgumentParser(description='Document QA bot')
    sub = parser.add_subparsers(dest='cmd')

    sub.add_parser('ingest')

    q = sub.add_parser('query')
    q.add_argument('--q', required=True, help='Question to ask')
    q.add_argument('--k', type=int, default=4)

    args = parser.parse_args()
    if args.cmd == 'ingest':
        ingest.ingest()
    elif args.cmd == 'query':
        results = query.query(args.q, k=args.k)
        if isinstance(results, dict):
            print('--- Answer ---')
            print(results.get('answer', ''))
            cites = results.get('citations', [])
            if cites:
                print('\n--- Citations ---')
                for c in cites:
                    print('-', c)
        else:
            # fallback: print raw results
            print(results)
    else:
        parser.print_help()

if __name__ == '__main__':
    main()
