import os
try:
    from pypdf import PdfReader
except Exception:
    PdfReader = None
try:
    import docx
except Exception:
    docx = None
import re
from typing import List


def extract_pdf_pages(file_path: str) -> List[dict]:
    """
    Extract text page-by-page from a PDF, returning list of dicts with metadata.
    """
    extracted = []
    file_name = os.path.basename(file_path)
    if PdfReader is None:
        print(f"Skipping PDF extraction for {file_name}: pypdf not installed")
        return extracted
    try:
        reader = PdfReader(file_path)
        for idx, page in enumerate(reader.pages):
            text = page.extract_text() or ""
            clean = " ".join(text.split())
            if clean:
                extracted.append({
                    "text": clean,
                    "metadata": {"source": file_name, "page": idx + 1}
                })
    except Exception as e:
        print(f"Error reading PDF {file_name}: {e}")
    return extracted


def extract_docx_pages(file_path: str) -> List[dict]:
    file_name = os.path.basename(file_path)
    if docx is None:
        print(f"Skipping DOCX extraction for {file_name}: python-docx not installed")
        return []
    try:
        doc = docx.Document(file_path)
        text = "\n".join(p.text for p in doc.paragraphs if p.text and p.text.strip())
        clean = " ".join(text.split())
        if clean:
            return [{"text": clean, "metadata": {"source": file_name, "page": 1}}]
    except Exception as e:
        print(f"Error reading DOCX {file_name}: {e}")
    return []


def extract_text_file(file_path: str) -> List[dict]:
    file_name = os.path.basename(file_path)
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            text = f.read()
        clean = " ".join(text.split())
        if clean:
            return [{"text": clean, "metadata": {"source": file_name, "page": 1}}]
    except Exception as e:
        print(f"Error reading text file {file_name}: {e}")
    return []


def _recursive_split(text: str, separators: List[str]) -> List[str]:
    if not separators:
        return [text]
    sep = separators[0]
    parts = [p for p in re.split(sep, text) if p and p.strip()]
    results = []
    for p in parts:
        results.extend(_recursive_split(p, separators[1:]))
    return results


def chunk_extracted_pages(pages: List[dict], chunk_size: int = 1000, chunk_overlap: int = 200) -> List[dict]:
    """
    Splits page-level documents into overlapping chunks while preserving metadata.
    Uses recursive splitting on paragraph and line breaks for semantic boundaries.
    """
    chunks = []
    separators = [r"\n\n+", r"\n+", r"\s"]

    for page in pages:
        text = page["text"]
        meta = page["metadata"]

        # Try semantic splits first
        parts = _recursive_split(text, separators)
        # Reconstruct into windowed chunks
        start = 0
        buffer = ""
        for part in parts:
            if buffer:
                candidate = buffer + " " + part
            else:
                candidate = part

            if len(candidate) >= chunk_size:
                # flush windows from buffer in sliding window style
                s = 0
                while s < len(candidate):
                    e = min(s + chunk_size, len(candidate))
                    chunk_text = candidate[s:e]
                    chunks.append({
                        "text": chunk_text,
                        "metadata": {**meta, "chunk_range": f"{s}-{e}"}
                    })
                    s += chunk_size - chunk_overlap
                buffer = ""
            else:
                buffer = candidate

        if buffer:
            chunks.append({"text": buffer, "metadata": {**meta, "chunk_range": "tail"}})

    return chunks

