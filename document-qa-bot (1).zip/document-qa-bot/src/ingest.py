"""Ingestion pipeline.

Reads documents from the data directory, extracts page-level text, splits it
into overlapping chunks, and persists them to a local ChromaDB collection. The
collection's embedding function (Gemini, or a local fallback) turns each chunk
into a vector automatically — we never call the embedding API by hand.
"""
import os

import chromadb

try:
    from tqdm import tqdm
except Exception:  # tqdm is a convenience only
    def tqdm(x, *a, **k):
        return x

from . import config, utils
from .embeddings import get_embedding_function


def ingest(
    data_dir: str = None,
    db_path: str = None,
    collection_name: str = None,
    chunk_size: int = None,
    chunk_overlap: int = None,
):
    data_dir = data_dir or config.DATA_DIR
    db_path = db_path or config.CHROMA_DB_PATH
    collection_name = collection_name or config.CHROMA_COLLECTION
    chunk_size = chunk_size or config.CHUNK_SIZE
    chunk_overlap = chunk_overlap or config.CHUNK_OVERLAP

    client = chromadb.PersistentClient(path=db_path)
    collection = client.get_or_create_collection(
        name=collection_name,
        embedding_function=get_embedding_function(),
        metadata={"hnsw:space": "cosine"},
    )

    all_docs = []
    for root, _, files in os.walk(data_dir):
        for fname in files:
            path = os.path.join(root, fname)
            lower = fname.lower()
            if lower.endswith(".pdf"):
                pages = utils.extract_pdf_pages(path)
            elif lower.endswith(".docx"):
                pages = utils.extract_docx_pages(path)
            elif lower.endswith(".txt") or lower.endswith(".md"):
                pages = utils.extract_text_file(path)
            else:
                continue

            chunks = utils.chunk_extracted_pages(
                pages, chunk_size=chunk_size, chunk_overlap=chunk_overlap
            )
            for i, c in enumerate(chunks):
                all_docs.append((f"{fname}::chunk::{i}", c["text"], c["metadata"]))

    if not all_docs:
        print(f"No documents found to ingest in '{data_dir}'.")
        return

    ids = [d[0] for d in all_docs]
    documents = [d[1] for d in all_docs]
    metadatas = [d[2] for d in all_docs]

    batch_size = 100
    for i in tqdm(range(0, len(ids), batch_size), desc="Indexing"):
        collection.add(
            ids=ids[i : i + batch_size],
            documents=documents[i : i + batch_size],
            metadatas=metadatas[i : i + batch_size],
        )

    print(f"Indexed {len(ids)} chunks into collection '{collection_name}' at {db_path}")
    return len(ids)


def index_status(db_path: str = None, collection_name: str = None) -> dict:
    """Return whether an index exists and how many chunks it holds."""
    db_path = db_path or config.CHROMA_DB_PATH
    collection_name = collection_name or config.CHROMA_COLLECTION
    try:
        client = chromadb.PersistentClient(path=db_path)
        collection = client.get_collection(
            name=collection_name, embedding_function=get_embedding_function()
        )
        return {"exists": True, "count": collection.count()}
    except Exception:
        return {"exists": False, "count": 0}


def reset_index(db_path: str = None, collection_name: str = None):
    """Delete the collection so it can be rebuilt from scratch."""
    db_path = db_path or config.CHROMA_DB_PATH
    collection_name = collection_name or config.CHROMA_COLLECTION
    client = chromadb.PersistentClient(path=db_path)
    try:
        client.delete_collection(name=collection_name)
    except Exception:
        pass


if __name__ == "__main__":
    ingest()
