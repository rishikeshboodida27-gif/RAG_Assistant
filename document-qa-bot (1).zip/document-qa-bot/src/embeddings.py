"""Embedding function selection.

Uses Gemini embeddings (via ChromaDB's native embedding function) when a
GEMINI_API_KEY is configured. Falls back to a deterministic local hash
embedding so the pipeline stays runnable offline and in tests without a key.
The SAME function must be used for ingestion and querying, or retrieval breaks.
"""
import hashlib
from typing import Any, Dict, List

import numpy as np
from chromadb import Documents, EmbeddingFunction, Embeddings
from chromadb.utils.embedding_functions import GoogleGenerativeAiEmbeddingFunction

from . import config


class HashEmbeddingFunction(EmbeddingFunction[Documents]):
    """Deterministic, dependency-free fallback embedding.

    Not semantically meaningful — it exists only so the app and tests run
    without an API key. Real retrieval quality requires the Gemini path.
    """

    def __init__(self, dim: int = 256):
        self.dim = dim

    def __call__(self, input: Documents) -> Embeddings:
        vectors = []
        for text in input:
            digest = hashlib.sha256((text or "").encode("utf-8")).digest()
            vec: List[float] = []
            cur = digest
            while len(vec) < self.dim:
                for b in cur:
                    if len(vec) >= self.dim:
                        break
                    vec.append((b / 127.5) - 1.0)
                cur = hashlib.sha256(cur).digest()
            vectors.append(np.asarray(vec[: self.dim], dtype=np.float32))
        return vectors

    @staticmethod
    def name() -> str:
        return "hash_embedding"

    def get_config(self) -> Dict[str, Any]:
        return {"dim": self.dim}

    @staticmethod
    def build_from_config(config: Dict[str, Any]) -> "HashEmbeddingFunction":
        return HashEmbeddingFunction(dim=config.get("dim", 256))


def get_embedding_function() -> EmbeddingFunction:
    """Return the Gemini embedding function if a key is set, else the fallback."""
    if config.GEMINI_API_KEY:
        return GoogleGenerativeAiEmbeddingFunction(
            api_key=config.GEMINI_API_KEY,
            model_name=config.EMBEDDING_MODEL,
        )
    print(
        "Warning: GEMINI_API_KEY not set — using local hash embeddings. "
        "Retrieval quality will be poor; set a key for real semantic search."
    )
    return HashEmbeddingFunction()


def using_gemini() -> bool:
    return bool(config.GEMINI_API_KEY)
