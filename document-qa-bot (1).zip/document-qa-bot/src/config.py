try:
    from dotenv import load_dotenv
except Exception:
    load_dotenv = None
import os

if load_dotenv is not None:
    load_dotenv()

# API keys
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY") or os.getenv("GENAI_API_KEY")

# Models (Gemini)
EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "models/gemini-embedding-001")
GENERATION_MODEL = os.getenv("GENERATION_MODEL", "gemini-2.5-flash")

# Paths
DATA_DIR = os.getenv("DATA_DIR", "data")
DB_DIR = os.getenv("DB_DIR", "db")
CHROMA_DB_PATH = os.getenv("CHROMA_DB_PATH", os.path.join(DB_DIR, "chroma_db"))
CHROMA_COLLECTION = os.getenv("CHROMA_COLLECTION", "document_knowledge_base")

# Chunking
CHUNK_SIZE = int(os.getenv("CHUNK_SIZE", "1000"))
CHUNK_OVERLAP = int(os.getenv("CHUNK_OVERLAP", "200"))
